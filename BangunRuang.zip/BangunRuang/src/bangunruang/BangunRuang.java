/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bangunruang;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class BangunRuang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      
        double jari,jari2,Tinggi ,s,Tinggi2;
        int menu;
        Double Sudut;
        char kembali,menu2,menu3;
        do {
             try{
            System.out.print("Masukkan Jari-jari : ");    
            jari=input.nextDouble();
            Lingkaran lingkaran=new Lingkaran(jari);
            System.out.println("Luas Lingkaran = "+lingkaran.getLuas());
          
            System.out.println("MENU");
            System.out.println("1. Bangun Datar");
            System.out.println("2. Bangun Ruang");
            
            System.out.print("Silahkan Pilih : ");
            menu = input.nextInt();
            switch (menu) {
                case 1:
                    System.out.println("Belum Selesai");
                    break;
                case 2:
                    System.out.println("\nBangun Ruang");
                    System.out.println("1. Bola");
                    System.out.println("2. Kerucut");
                    System.out.println("3. Tabung");
                    menu3=input.next().charAt(0);
                    switch(menu3){
                        case '1':
                            Bola t=new Bola(jari);
                            System.out.println("\nBOLA");
                            System.out.println("Volume     = "+t.volumeBola());
                            
                            break;
                        case '2':
                            System.out.print("Masukkan Garis Pelukis  : ");
                            s=input.nextDouble();
                            System.out.print("Masukkan Tinggi Kerucut  : ");   
                            Tinggi=input.nextDouble();
                            
                            Kerucut kerucut=new Kerucut(jari);
                            System.out.println("\nLEVEL 2");
                            System.out.println("\nKERUCUT");
                            System.out.println("Luas Permukaan = "+kerucut.luasKerucut(s));
                            System.out.println("Volume Kerucut = "+kerucut.volumeKerucut(jari,Tinggi));
                            System.out.println("\n\nBangun Ruang");
                            System.out.println("\nLEVEL 3");
                           break;
                        case '3':
                            System.out.print("Masukkan Tinggi : ");    
                            Tinggi=input.nextDouble();
                            Tabung tabung=new Tabung(Tinggi,jari);
                            tabung.setTinggi(Tinggi);
                            System.out.println("Luas Permukaan = "+tabung.getLuasTabung());
                            System.out.println("Volume         = "+tabung.getVolumeTabung());
                            break;
                     
                        
                    }
               break;
            }
             
                }catch (InputMismatchException e){
                    System.err.println("Input berupa angka Tidak Boleh Huruf!");
                  input.nextLine();
                }catch(ArithmeticException exception){
                    System.out.println("Exception: Suatu integer "
						+ "tidak dapat dibagi oleh nol!");
                    input.nextLine();
               }  catch(Exception er){
                    System.out.println("Hasil UnDefine dengan nilai 0");
                    input.nextLine();
               }  
            
            
            System.out.print("Kembali ke menu? <y|n> : ");
            kembali = input.next().charAt(0);
            
        } while (kembali == 'y' || kembali == 'Y');

       
        
    }
    
}
